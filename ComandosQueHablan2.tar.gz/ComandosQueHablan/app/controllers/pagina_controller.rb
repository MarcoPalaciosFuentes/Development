class PaginaController < ApplicationController
  def home
  end
end
