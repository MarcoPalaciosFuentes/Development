class StaticController < ApplicationController
  def main
  end

  def usuario
  end
end
