class Usuario < ActiveRecord::Base
  has_secure_password
end
