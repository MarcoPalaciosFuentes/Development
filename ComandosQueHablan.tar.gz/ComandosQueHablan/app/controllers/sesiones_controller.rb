class SesionesController < ApplicationController
  def new
  end



  def create
    usuarios = usuarios.find_by_email(params[:email])
    if usuarios && usuarios.authenticate(params[:password])
    	sesion[:usuario_id] = usuario_id
    	redirect_to root_url, notice: "logeado"
    else
    	flash.now.alert = "nombre de usuario o password incorrecta"
    	render "new"
    end
  end
end
