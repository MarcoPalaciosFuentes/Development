class Usuarios < ActiveRecord::Migration
  def change
  end
end
