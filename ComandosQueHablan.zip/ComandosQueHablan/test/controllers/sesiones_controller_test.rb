require 'test_helper'

class SesionesControllerTest < ActionController::TestCase
  test "should get new" do
    get :new
    assert_response :success
  end

end
